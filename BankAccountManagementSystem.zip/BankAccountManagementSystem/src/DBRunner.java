import com.helpers.ConnectionUtility;

import java.sql.Connection;

public class DBRunner {
    public static void main(String[] args) {
        Connection conn ;
        conn = ConnectionUtility.getConnection();
        System.out.println(conn);
    }
}
