package com.services;

import com.beans.Account;

import java.util.ArrayList;

public interface IAccountService {
    void addAccount(Account account);
    ArrayList<Account> displayAllAccounts();
    Account displayAccountById(String accountId);
    void performPayment(Account account, double amount);
    void performPayment(Account account, double amount, String password);
    void performDeposit(Account account, double amount);
    void performDeposit(Account account, double amount, String password);
    void deleteAccount(Account account);
}
