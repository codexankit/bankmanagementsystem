package com.services;

import com.beans.Account;

import java.util.ArrayList;

public interface IAccountDBService {
    void addAccount(Account account);
    ArrayList<Account> displayAllAccounts();
    Account displayAccountById(String accountId);
    void updateAccount(Account account);
    void deleteAccount(Account account);

}
