package com.controller;

import com.beans.Account;
import com.beans.CreditAccount;
import com.beans.DebitAccount;
import com.exception.AccountException;
import com.helpers.CustomerDataValidator;
import com.serviceImpl.AccountServiceImpl;
import com.services.IAccountService;

import java.util.ArrayList;
import java.util.Scanner;

public class AccountController {
    private final IAccountService accountService=new AccountServiceImpl();
    public void addAccount(Scanner scanner) {
        try {

            System.out.println("Please enter account details");
            System.out.print("Enter account type(Credit or Debit): ");
            String type=scanner.nextLine().toLowerCase();
            if (CustomerDataValidator.accountTypeValidator(type)) {
                System.out.println("Enter account number: ");
                String accountNum=scanner.nextLine();
                if (CustomerDataValidator.accountIDValidator(accountNum)) {
                    System.out.println("Enter account owner: ");
                    String accountOwner=scanner.nextLine();
                    if (CustomerDataValidator.nameValidator(accountOwner)) {
                        System.out.println("Enter balance: ");
                        double balance =scanner.nextDouble();
                        scanner.nextLine();
                        if (CustomerDataValidator.balanceValidator(balance)) {
                            Account account =null;

                            if(type.equals("credit"))
                            {
                                CreditAccount creditAccount= new CreditAccount(accountNum,accountOwner,balance);
                                System.out.println("Enter limit: ");
                                double limit=scanner.nextDouble();
                                scanner.nextLine();
                                if (CustomerDataValidator.balanceValidator(limit)) {
                                    creditAccount.setLimit(limit);
                                    accountService.addAccount(creditAccount);
                                    account=creditAccount;
                                }
                            }
                            else if(type.equals("debit"))
                            {
                                System.out.println("Enter password: ");
                                String password=scanner.nextLine();
//                                if (CustomerDataValidator.passwordValidator(password)) {
                                    DebitAccount debitAccount= new DebitAccount(accountNum,accountOwner,balance, password);
                                    accountService.addAccount(debitAccount);
                                    account=debitAccount;
//                                }


                            }
                            System.out.println("Account has been sucessfully added!");
                            System.out.println("Current ArrayList size: "+accountService.displayAllAccounts().size());
                            System.out.println("Account added account: "+account);

                        }

                    }
                }
            }

        }
        catch (AccountException e) {
            System.out.println(e);
        }
    }

    
    public void displayAllAccounts() {
        ArrayList<Account> accounts = accountService.displayAllAccounts();
        if(accounts == null)
        {
            System.out.println("No accounts found");
            return;
        }
        System.out.println("All accounts from List: ");
        for(int i=0;i<accounts.size();i++)
        {
            System.out.println((i+1)+". "+accounts.get(i));
        }
    }

    
    public void displayAccountById(Scanner scanner) {
        try {
            System.out.println("Please enter account id: ");
            String accountId = scanner.nextLine();
            if (CustomerDataValidator.accountIDValidator(accountId)) {
                Account account = accountService.displayAccountById(accountId);
                if (account != null) {
                    System.out.println(account);
                } else {
                    System.out.println("Account not found");
                }

            }
        }
        catch (AccountException e) {
            System.out.println(e);
        }

    }

    
    public void performPayment(Scanner scanner) {
        try {
            System.out.println("Please Enter the amount id: ");
            String accountId=scanner.nextLine();
            if(CustomerDataValidator.accountIDValidator(accountId)){
                Account account=accountService.displayAccountById(accountId);
                if(account==null)
                {
                    System.out.println("Account not found. ");
                    return;

                }
                System.out.print("Please enter the amount: ");
                double amount= scanner.nextDouble();
                scanner.nextLine();
                if(CustomerDataValidator.balanceValidator(amount))
                {
                    if(account instanceof DebitAccount)
                    {
                        System.out.print("Enter the password: ");
                        String password=scanner.nextLine();
//                        System.out.println(password);

                        if(CustomerDataValidator.passwordValidator(password))
                        {
                            accountService.performPayment(account, amount,password);

                        }

                    }
                    else if(account instanceof CreditAccount)
                    {
                        accountService.performPayment(account, amount);

                    }
                    else {
                        account.performPayment(amount);
                    }

                }


            }


        }
        catch (AccountException e) {
            System.out.println(e);
        }


    }

    
    public void performDeposit(Scanner scanner) {
        try{
            System.out.print("Please Enter the account id: ");
            String accountId=scanner.nextLine();
            if(CustomerDataValidator.accountIDValidator(accountId))
            {
                Account account=accountService.displayAccountById(accountId);
                if(account==null) {
                    System.out.println("Account not found");
                    return ;
                }
                System.out.print("Please enter the amount: ");
                double amount=scanner.nextDouble();
                scanner.nextLine();
                if(CustomerDataValidator.balanceValidator(amount))
                {
                    if(account instanceof DebitAccount)
                    {
                        System.out.println("Enter the password: ");

                        String password1=scanner.nextLine();

                        if(CustomerDataValidator.passwordValidator(password1))
                        {
                            accountService.performDeposit(account, amount,password1);

                        }


                    }
                    else {
                        accountService.performDeposit(account,amount);
                    }

                }

            }

        }
        catch (AccountException e) {
            System.out.println(e);
        }

    }

    
    public void deleteAccount(Scanner scanner) {
        try{
            System.out.print("Please Enter the account id: ");
            String accountId=scanner.nextLine();
            if(CustomerDataValidator.accountIDValidator(accountId))
            {
                Account account=accountService.displayAccountById(accountId);
                if(account!=null)
                {
                    accountService.deleteAccount(account);
                    System.out.println("Account has been deleted successfully");
                }
                else
                {
                    System.out.println("Account not found");
                }

            }



        }
        catch (AccountException e)
        {
            System.out.println(e);
        }

    }
}
