package com.serviceImpl;

import com.beans.Account;
import com.beans.CreditAccount;
import com.beans.DebitAccount;
import com.helpers.ConnectionUtility;
import com.services.IAccountDBService;
import com.services.IAccountService;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDBServiceImpl implements IAccountDBService {
    static Connection conn= ConnectionUtility.getConnection();
    @Override
    public void addAccount(Account account) {
        try{
            String sql="Insert into accounts (accountnum,accountowner,balance)VALUES (?,?,?)";
            PreparedStatement pstmt= conn.prepareStatement(sql);
            pstmt.setString(1,account.getAccountNum());
            pstmt.setString(2,account.getAccountOwner());
            pstmt.setDouble(3,account.getBalance());
            pstmt.executeUpdate();

            if(account instanceof DebitAccount)
            {
                String sqldebit="Insert into debitaccounts (accountnum, account_password) VALUES (?,?)";
                PreparedStatement pstmtdebit= conn.prepareStatement(sqldebit);
                pstmtdebit.setString(1,account.getAccountNum());
                pstmtdebit.setString(2,((DebitAccount) account).getPassword());
                pstmtdebit.executeUpdate();
            }
            else {
                String sqlcredit="Insert into creditaccounts (accountnum, bonuspoint,account_limit) VALUES (?,?,?)";
                PreparedStatement pstmtcredit= conn.prepareStatement(sqlcredit);
                pstmtcredit.setString(1,account.getAccountNum());
                pstmtcredit.setInt(2,((CreditAccount)account).getBonusPoint());
                pstmtcredit.setDouble(3,((CreditAccount) account).getLimit());
                pstmtcredit.executeUpdate();
            }
        }
        catch (SQLException e)
        {
            StackTraceElement[] trace = e.getStackTrace();
            for(StackTraceElement element : trace){
                System.out.println("Exception at : "+ element);
            }
        }
    }

    @Override
    public ArrayList<Account> displayAllAccounts() {
        ArrayList<Account> accounts=new ArrayList<>();
        String querycredit="SELECT * FROM Accounts INNER JOIN CreditAccounts USING (accountnum)";
        String querydebit="SELECT * FROM Accounts INNER JOIN DebitAccounts USING (accountnum)";
        try{
            PreparedStatement pstmt = conn.prepareStatement(querycredit);
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()){
                CreditAccount customer = new CreditAccount();
                customer.setAccountNum(rs.getString("accountnum"));
                customer.setAccountOwner(rs.getString("accountowner"));
                customer.setBalance(rs.getDouble("balance"));
                customer.setBonusPoint(rs.getInt("bonuspoint"));
                customer.setLimit(rs.getDouble("account_limit"));
                accounts.add(customer);
            }
            pstmt = conn.prepareStatement(querydebit);
            ResultSet r = pstmt.executeQuery();
            while(r.next()){
                DebitAccount customer = new DebitAccount();
                customer.setAccountNum(r.getString("accountnum"));
                customer.setAccountOwner(r.getString("accountowner"));
                customer.setBalance(r.getDouble("balance"));
                customer.setPassword(r.getString("account_password"));
                accounts.add(customer);
            }
        }
        catch (SQLException e){
            StackTraceElement[] trace = e.getStackTrace();
            for(StackTraceElement element : trace){
                System.out.println("Exception at : "+ element);
            }
        }
        return accounts;


    }

    @Override
    public Account displayAccountById(String accountId) {
        Account account=null;
        String querycredit="SELECT * FROM Accounts as a INNER JOIN CreditAccounts USING (accountnum) where a.accountnum=?";
        String querydebit="SELECT * FROM Accounts as a INNER JOIN DebitAccounts USING (accountnum) where a.accountnum=?";
        try {
            PreparedStatement pstmt = conn.prepareStatement(querycredit);
            pstmt.setString(1, accountId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                CreditAccount creditAccount = new CreditAccount();
                creditAccount.setAccountNum(rs.getString("accountnum"));
                creditAccount.setAccountOwner(rs.getString("accountowner"));
                creditAccount.setBalance(rs.getDouble("balance"));
                creditAccount.setBonusPoint(rs.getInt("bonuspoint"));
                creditAccount.setLimit(rs.getDouble("account_limit"));
                account=creditAccount;
            }
            pstmt = conn.prepareStatement(querydebit);
            pstmt.setString(1, accountId);
            ResultSet r = pstmt.executeQuery();
            while (r.next()) {
                DebitAccount debitAccount = new DebitAccount();
                debitAccount.setAccountNum(r.getString("accountnum"));
                debitAccount.setAccountOwner(r.getString("accountowner"));
                debitAccount.setBalance(r.getDouble("balance"));
                debitAccount.setPassword(r.getString("account_password"));
                account=debitAccount;
            }
        }
        catch(SQLException e)
        {
            StackTraceElement[] trace = e.getStackTrace();
            for(StackTraceElement element : trace){
                System.out.println("Exception at : "+ element);
            }

        }
        return account;

    }

    @Override
    public void updateAccount(Account account) {
        try {
            if (account instanceof DebitAccount) {
                String querydebit = "UPDATE Accounts SET balance=? where accountnum=?";
                PreparedStatement pstmt = conn.prepareStatement(querydebit);
                pstmt.setDouble(1, account.getBalance());
                pstmt.setString(2, account.getAccountNum());
                int count = pstmt.executeUpdate();

            }
            else{
                String querycredit1= "UPDATE Accounts SET balance = ? WHERE accountnum = ?";
                String querycredit2 = "UPDATE CreditAccounts SET bonuspoint = ? WHERE accountnum = ?";
                PreparedStatement pstmt1 = conn.prepareStatement(querycredit1);
                pstmt1.setDouble(1, account.getBalance());
                pstmt1.setString(2, account.getAccountNum());
                PreparedStatement pstmt2 = conn.prepareStatement(querycredit2);
                pstmt2.setInt(1, ((CreditAccount)account).getBonusPoint());
                pstmt2.setString(2, account.getAccountNum());
                int count1 = pstmt1.executeUpdate();
                int count2 = pstmt2.executeUpdate();

            }
        }

        catch (SQLException e){
            StackTraceElement[] trace = e.getStackTrace();
            for(StackTraceElement element : trace){
                System.out.println("Exception at : "+ element);
            }
        }

    }



    @Override
    public void deleteAccount(Account account) {
        try {
            if (account instanceof DebitAccount) {
                String querydebit1= "Delete from Debitaccounts where accountnum= ?";
                PreparedStatement pstmt1 = conn.prepareStatement(querydebit1);
                pstmt1.setString(1, account.getAccountNum());
                String querydebit2 = "DELETE from accounts where accountnum= ?";
                PreparedStatement pstmt2 = conn.prepareStatement(querydebit2);
                pstmt2.setString(1, account.getAccountNum());
                int count1 = pstmt1.executeUpdate();
                int count2 = pstmt2.executeUpdate();

            }
            else{
                String querycredit1= "Delete from Creditaccounts where accountnum= ?";
                PreparedStatement pstmt1 = conn.prepareStatement(querycredit1);
                pstmt1.setString(1, account.getAccountNum());
                String querycredit2 = "DELETE from accounts where accountnum= ?";
                PreparedStatement pstmt2 = conn.prepareStatement(querycredit2);
                pstmt2.setString(1, account.getAccountNum());
                int count1 = pstmt1.executeUpdate();
                int count2 = pstmt2.executeUpdate();
            }
        }

        catch (SQLException e){
            StackTraceElement[] trace = e.getStackTrace();
            for(StackTraceElement element : trace){
                System.out.println("Exception at : "+ element);
            }
        }

    }
}
