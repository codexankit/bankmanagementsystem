package com.serviceImpl;

import com.beans.Account;
import com.beans.CreditAccount;
import com.beans.DebitAccount;
import com.services.IAccountService;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class AccountServiceImpl implements IAccountService {
    private ArrayList<Account> accounts;

    public AccountServiceImpl()
    {
        accounts=new ArrayList();

    }
    public static AccountDBServiceImpl accountDBService=new AccountDBServiceImpl();
    @Override
    public void addAccount(Account account) {
        accountDBService.addAccount(account);
    }

    @Override
    public ArrayList<Account> displayAllAccounts() {
        return accountDBService.displayAllAccounts();
    }

    @Override
    public Account displayAccountById(String accountId) {
        return accountDBService.displayAccountById(accountId);
    }

    @Override
    public void performPayment(Account account, double amount) {
        ((CreditAccount)account).performPayment(amount);
        accountDBService.updateAccount(account);
    }

    @Override
    public void performPayment(Account account, double amount, String password) {
        ((DebitAccount) account).performPayment(amount, password);
        accountDBService.updateAccount(account);
        // update account1 in db using its accountNum
    }

    @Override
    public void performDeposit(Account account, double amount) {
        ((CreditAccount)account).performDeposit(amount);
        accountDBService.updateAccount(account);
    }
    @Override
    public void performDeposit(Account account, double amount, String password) {
        ((DebitAccount) account).performDeposit(amount, password);
        accountDBService.updateAccount(account);
    }

    @Override
    public void deleteAccount(Account account) {
        accountDBService.deleteAccount(account);
    }
}
