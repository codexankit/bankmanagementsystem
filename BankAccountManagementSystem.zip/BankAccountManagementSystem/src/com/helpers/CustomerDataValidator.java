package com.helpers;


import com.exception.AccountException;

public class CustomerDataValidator {
    public static boolean nameValidator(String name) throws AccountException {

        String namePattern = "^[A-Za-z]+$";
        if(name.matches(namePattern)){
            return true;
        }
        else {
            throw new AccountException("Name only contains alphabets");
        }
    }

    public static boolean balanceValidator(double bal) throws AccountException {

        if(bal >= 0){
            return true;
        }
        else {
            throw new AccountException("Amount cannot be negative");
        }
    }
    public static boolean passwordValidator(String pass) throws AccountException {
        String contactPattern = "^.{4,15}$";
        if(pass.matches(contactPattern)){
            return true;
        }
        else {
            throw new AccountException("Password should be between 4-15 in length");
        }
    }
    public static boolean accountIDValidator(String accountId) throws AccountException {
        String emailPattern = "^[0-9]+$";
        if(accountId.matches(emailPattern)){
            return true;
        }
        else {
            throw new AccountException("AccountId is invalid");
        }
    }
    public static boolean accountTypeValidator(String accountType) throws AccountException {
        if(accountType.equalsIgnoreCase("Credit") || accountType.equalsIgnoreCase("Debit")){
            return true;
        }
        else {
            throw new AccountException("Account Type can be only Credit/Debit");
        }
    }
}
