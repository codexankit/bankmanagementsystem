package com.UI;

import com.beans.Account;
import com.beans.CreditAccount;
import com.beans.DebitAccount;
import com.controller.AccountController;

import java.util.ArrayList;
import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        AccountController controller = new AccountController();
        Scanner scanner=new Scanner(System.in);

        System.out.println("===Bank Account Management System===");
        //create account object  and test methods
        System.out.println("==Testing account Class==");
        Account testAccount = new Account("123", "Kunal", 5000);
        System.out.println("Initial Account: " + testAccount);
        testAccount.performPayment(2000);
        testAccount.performDeposit(1000);
        Account creditAcc = new CreditAccount("101", "customer01", 1000);
        Account debitAcc = new DebitAccount("202", "customer02", 3000, "admin123");
        System.out.println("Arraylist Demo: ");
        ArrayList<Account> accountList = new ArrayList<>();
        accountList.add(testAccount);
        accountList.add(creditAcc);
        accountList.add(debitAcc);
        System.out.println("ArrayList contains" + accountList.size() + "account");
        for (int i = 0; i < accountList.size(); i++) {
            System.out.println((i + 1) + "." + accountList.get(i));
        }
        System.out.println("\n Starting Interactive Application");
        System.out.println("\n Welcome to Standard Chartered Bank. ");
        System.out.println("Please Enter your choice");
        System.out.println("1. for Add new account");
        System.out.println("2. for Display all accounts");
        System.out.println("3. for Display account by ID");
        System.out.println("4. for Perform payment");
        System.out.println("5. for Perform deposit");
        System.out.println("6. for Delete selected account");
        System.out.println("7. for Exit the bank application");
        boolean exit=false;
        while(!exit)
        {
            System.out.println("Enter your choice: ");
            int choice=scanner.nextInt();
            scanner.nextLine();
            switch(choice)
            {
                case 1:
                    controller.addAccount(scanner);
                    break;
                case 2:
                    controller.displayAllAccounts();
                    break;
                case 3:
                    controller.displayAccountById(scanner);
                    break;
                case 4:
                    controller.performPayment(scanner);
                    break;
                case 5:
                    controller.performDeposit(scanner);
                    break;
                case 6:
                    controller.deleteAccount(scanner);
                    break;
                case 7:
                    System.out.println("Thank you for using Standard Chartered Bank!");
                    exit =true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        }
    }

}


