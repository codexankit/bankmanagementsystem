package com.beans;


import com.helpers.CustomerDataValidator;

public class Account{
    String accountNum;
    String accountOwner;
    double balance;

    public String getAccountNum() {
        return accountNum;
    }

    public void setAccountNum(String accountNum) {
        this.accountNum = accountNum;
    }

    public String getAccountOwner() {
        return accountOwner;
    }

    public void setAccountOwner(String accountOwner) {
        this.accountOwner = accountOwner;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Account() {
    }

    public Account(String accountNum, String accountOwner, double balance) {
        this.accountNum = accountNum;
        this.accountOwner = accountOwner;
        this.balance = balance;
    }

    public void performPayment(double amount)  {
    if(amount>0 && amount <=balance) {
        balance -= amount;
        System.out.println("Payment of Rs " + amount + "Completed. New balance : Rs" + balance);
    }
    else
    {
        System.out.println("Payment failed . Insufficient balance or invalid amount. ");
    }



    }

    public void performDeposit(double amount) {
        if(amount > 0)
        {
            balance+=amount;
            System.out.println("Deposit of Rs"+ amount+"completed. New balance: $"+balance);
        }
        else {
            System.out.println("Invalid Deposit amount.");
        }
    }
    @Override
    public String toString()
    {
        return getClass().getSimpleName() + "[accountNum=" + accountNum + ", accountOwner="+ accountOwner +", balance="+ balance+"]";
    }

}
