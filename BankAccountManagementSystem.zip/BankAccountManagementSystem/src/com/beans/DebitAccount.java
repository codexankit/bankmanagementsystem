package com.beans;

public class DebitAccount extends Account{

    String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public DebitAccount() {
    }

    public DebitAccount(String accountNum, String accountOwner, double balance, String password) {
        super(accountNum, accountOwner, balance);
        this.password = password;
    }

    public void performPayment(double amount, String password) {
     if( amount<=0)
     {
         System.out.println("Invalid Payment amount.");
         return;
     }
     if(this.password.equalsIgnoreCase(password))
     {
         if(amount<=balance)
         {
             balance-=amount;
             System.out.println("Debit payment of Rs "+amount +" New balance: $"+balance);

         }
         else System.out.print("Payment failed. Insufficient balance");
         return;
     }
     System.out.println("Payment failed. Incorrect password");
    }

    public void performDeposit(double amount, String password) {
        if( amount<=0)
        {
            System.out.println("Invalid Deposit amount.");
            return;
        }
        if(this.password.equalsIgnoreCase(password))
        {
            balance+=amount;
            System.out.println("Debit account deposit of Rs"+ amount + "completed. New Balance : Rs"+ balance);
            return;
        }
        System.out.println("Deposit failed. Incorrect password");

    }
    @Override
    public String toString()
    {
        return "DebitAccount [password="+password + ", accountNum="+accountNum+ ", accountOwner="+accountOwner+ ", balance="+balance+ "]";
    }

}
