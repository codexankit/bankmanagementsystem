package com.beans;

public class CreditAccount extends Account{
    int bonusPoint = 0;
    double limit;

    public int getBonusPoint() {
        return bonusPoint;
    }

    public void setBonusPoint(int bonusPoint) {
        this.bonusPoint = bonusPoint;
    }

    public double getLimit() {
        return limit;
    }

    public void setLimit(double limit) {
        this.limit = limit;
    }

    public CreditAccount() {
    }

    public CreditAccount(String accountNum, String accountOwner, double balance) {
        super(accountNum, accountOwner, balance);
    }

    @Override
    public void performPayment(double amount) {
        if(amount<=0)
        {
            System.out.print("Invalid payment amount. ");
            return;

        }
        double availablecredit=balance+limit;
        if(amount<=availablecredit)
        {
            balance-=amount;
            // add bonus point
            bonusPoint+=(int)(amount/100);
            System.out.println("Credit payment of Rs"+ amount+" Completed.");
            System.out.println("Bonus points earned: "+(int)(amount/100));
            System.out.println("New balance: $"+balance+",Total bonus points: "+bonusPoint);


        }
        else {
            System.out.println("Payment failed. Amount exceeds credit limit. ");
        }
    }


    @Override
    public void performDeposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Credit account deposit of $" + amount + " completed. New balance : $" + balance);
        }
        else
        {
            System.out.println("Payment failed. Amount exceeds credit limit");
        }


    }
    @Override
    public String toString()
    {
        return "CreditAccount [bonusPoint ="+bonusPoint +", limit="+ limit+", accountNum="+ accountNum + ", accountOwner="+ accountOwner+", balance=" + balance+"]";
    }


}
