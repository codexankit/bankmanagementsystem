package com.exception;

public class AccountException extends Exception{
    String msg;
    public AccountException(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return this.msg;
    }
}
